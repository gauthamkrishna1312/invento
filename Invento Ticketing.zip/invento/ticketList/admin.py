from django.contrib import admin
from .models import ticket_info

# Register your models here.
admin.site.register(ticket_info)